import React from 'react'
import { Link } from 'react-router-dom'
import BannerImage from '../assets/background.jpg'
import '../styles/Home.css'

function Home() {
  return (
    <div className="home"  style={{backgroundImage: `url(${BannerImage})`}}>
        <div className="headerContainer">
            <h1> Soe's Combat Solutions </h1>
              <p> "Empowering Your Defense." </p>
              <Link to="menu">
                  <button> BUY NOW </button>
              </Link>
             
        </div>
    </div>
  )
}

export default Home;
