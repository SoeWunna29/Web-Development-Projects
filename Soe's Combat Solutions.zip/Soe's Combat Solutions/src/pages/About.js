import React from 'react'
import AboutPic from '../assets/aboutus.jpg'
import '../styles/About.css'


function About() {
  return (
    <div className="about">
          <div className="aboutTop"
              style={{ backgroundImage: `url(${AboutPic})` }}>
              </div>
          <div className="aboutBottom">
              <h1> About Us </h1>
              <p> Welcome to Soe's Combat Solutions! We are a premier firearm shop that has been serving
                  our valued customers since 2022. With a passion for firearms and a commitment to
                  exceptional service, we have quickly become a trusted destination for
                  all your firearm needs. At Soe's Combat Solutions, we pride ourselves on offering
                  a wide selection of high-quality firearms, accessories, and ammunition,
                  catering to the needs of both enthusiasts and professionals alike.
                  Our knowledgeable and friendly staff are here to provide expert advice,
                  ensuring that you find the perfect firearm that suits your specific requirements.
                  Whether you are a seasoned shooter or just beginning your journey into
                  the world of firearms, Soe's Combat Solutions is your go-to destination for
                  top-notch products and unparalleled customer service.</p>
          </div>
    </div>
  )
}

export default About
