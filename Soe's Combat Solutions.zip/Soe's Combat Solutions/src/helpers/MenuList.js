import BerettaM9A4 from "../assets/berettam9a4.jpg"
import ColtM4Monolithic from "../assets/coltm4monolithic.jpg"
import ColtM4Socom from "../assets/coltm4socom.jpg"
import FNScar17s from "../assets/fnscar17s.jpg"
import BarrettM82 from "../assets/barrettm82.jpg"
import BrowningM2 from "../assets/m2browning.jpg"
import M240SL from "../assets/m240slr.jpg"
import Tavor7 from "../assets/tavor7.jpg"
import FNFiveSeve from "../assets/fnfiveseven.jpg"

export const MenuList = [
    {
        name: "Beretta M9A4",
        image: BerettaM9A4,
        price: 899
    },
    {
        name: "Colt M4 Monolithic",
        image: ColtM4Monolithic,
        price: 1599
    },
    {
        name: "FN Five Seven",
        image: FNFiveSeve,
        price: 1299
    },
    {
        name: "FN Scar 17s",
        image: FNScar17s,
        price: 3749
    },
    {
        name: "Colt M4 SOCOM",
        image: ColtM4Socom,
        price: 1499
    },
    {
        name: "IWI Tavor 7",
        image: Tavor7,
        price: 2199
    },
    {
        name: "Barrett M82",
        image: BarrettM82,
        price: 12999
    },
    {
        name: "M240 SL",
        image: M240SL,
        price: 13999
    },
    {
        name: "Browning M2 .50Cal",
        image: BrowningM2,
        price: 16999
    },
]